#!/bin/bash
mvn install:install-file -Dfile=wlthint3client.jar  -DgroupId=weblogic -DartifactId=wlthint3client -Dversion=10.3.6 -Dpackaging=jar
