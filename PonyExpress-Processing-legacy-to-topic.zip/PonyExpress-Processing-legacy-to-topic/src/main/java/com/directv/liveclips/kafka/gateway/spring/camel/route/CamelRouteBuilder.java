package com.directv.liveclips.kafka.gateway.spring.camel.route;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.RouteDefinition;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.jms.ConnectionFactory;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@Component
public class CamelRouteBuilder extends RouteBuilder implements DisposableBean {
    public static final String END_POINT_SEPARATOR = "__";
    private final ArrayList<RouteDefinition> routes = new ArrayList<>();


    private String legacyEndPoint;
    private String newEndPoint;

    public CamelRouteBuilder() {
        // for reflection based applications
    }

    @Autowired
    public CamelRouteBuilder(@Value("${legacy.end.point.uri}") String legacyEndPoint, @Value("${new.end.point.uri}") String newEndPoint) {
        this.legacyEndPoint = legacyEndPoint;
        this.newEndPoint = newEndPoint;
    }

    @Override
    public void configure() throws Exception {
        if (legacyEndPoint != null && newEndPoint != null) {
            final String[] legacyEndPoints = legacyEndPoint.split(END_POINT_SEPARATOR);
            final String[] newEndPoints = newEndPoint.split(END_POINT_SEPARATOR);
            log.debug(" ****************************************** Configure Route Start ***************** ");
            for (int i = 0; i < legacyEndPoints.length; i++) {
                log.debug("Configuring route FROM " + legacyEndPoints[i] + " TO " + newEndPoints[i]);
                routes.add(from(legacyEndPoints[i]).to(newEndPoints[i]));
            }
            log.debug(" ****************************************** Configure Route End ***************** ");
        }
    }


    public List<RouteDefinition> getRoutes() {
        return routes;
    }

    @Override
    public void destroy() throws Exception {
        routes.clear();
    }

    static {
        try {
            Class klass = ConnectionFactory.class;
            URL location = klass.getResource('/'+klass.getName().replace('.', '/')+".class");
            System.out.println(" ....................................................  "+location);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
