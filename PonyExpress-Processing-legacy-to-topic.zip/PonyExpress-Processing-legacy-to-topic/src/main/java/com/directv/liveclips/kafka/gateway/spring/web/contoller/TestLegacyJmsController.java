package com.directv.liveclips.kafka.gateway.spring.web.contoller;

import com.directv.liveclips.kafka.gateway.spring.web.form.TestLegacyJmsForm;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.CamelContext;
import org.apache.camel.model.RouteDefinition;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by svarkey on 22/12/16.
 */
@Controller
public class TestLegacyJmsController {

    public static final String TEST_LEGACY_JMS = "testLegacyJms";
    public static final String TEST_LEGACY_JMS_FORM = "testLegacyJmsForm";
    public static final String SPRING_CONTEXT_LIST = "springContextList";
    public static final String END_POINTS_JSON = "endPointsJson";
    public static final String SUCCESS = "Success";
    public static final String RESPONSE_TEXT = "responseText";
    public static final String EXCEPTION = "exception";
    public static final String MESSAGE = "message";
    public static final String QUEUE = "queue";
    private static final String DEST_CONTEXT_LIST = "destinationList";
    private static Logger logger = Logger.getLogger(TestLegacyJmsController.class);

    @Autowired
    private ApplicationContext applicationContext;
    private final HashMap<String, HashMap<String, String>> camelContextEndpointsMap = new HashMap<>();
    private final ArrayList<String> camelContextList = new ArrayList<>();


    @RequestMapping(value = "/index.html", method = RequestMethod.GET)
    public String testLegacyJms(ModelMap testLegacyJmsModel) {
        createCamelContextEndpointsMap();
        TestLegacyJmsForm testLegacyJmsForm = new TestLegacyJmsForm(camelContextList.isEmpty() ? "" : camelContextList.get(0));
        testLegacyJmsModel.addAttribute(TEST_LEGACY_JMS_FORM, testLegacyJmsForm);
        testLegacyJmsModel.put(SPRING_CONTEXT_LIST, camelContextList);
        testLegacyJmsModel.put(DEST_CONTEXT_LIST, camelContextEndpointsMap.get(testLegacyJmsForm.getSpringContext()));
        storeJsonInModelMap(testLegacyJmsModel, camelContextEndpointsMap);
        return TEST_LEGACY_JMS;
    }

    private void storeJsonInModelMap(ModelMap model, HashMap<String, HashMap<String, String>> stringHashMapHashMap) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String endPointsJson = objectMapper.writeValueAsString(stringHashMapHashMap);
            model.put(END_POINTS_JSON, endPointsJson);
        } catch (Exception e) {
            logger.error("Parsing error ", e);
        }
    }

    private void createCamelContextEndpointsMap() {
        final String[] beans = applicationContext.getBeanNamesForType(SpringCamelContext.class);
        if (camelContextEndpointsMap.isEmpty()) {
            for (String bean : beans) {
                HashMap<String, String> stringStringHashMap = new HashMap<>();
                CamelContext springCamelContext = applicationContext.getBean(bean, SpringCamelContext.class);
                List<RouteDefinition> routeDefinitions = springCamelContext.getRouteDefinitions();
                routeDefinitions.forEach(routeDefinition -> {
                    String endPointKey = springCamelContext.getRoute(routeDefinition.getId()).getEndpoint().getEndpointKey().replace("ref://", "");
                    String endPointKeyUri = springCamelContext.getEndpoint(endPointKey).getEndpointConfiguration().getURI().toString();
                    stringStringHashMap.put(endPointKeyUri, endPointKeyUri);
                });
                camelContextList.add(bean);
                camelContextEndpointsMap.put(bean, stringStringHashMap);
            }
        }
    }

    @RequestMapping(value = "/process.html", method = RequestMethod.POST,
            consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE},
            headers = "Accept=*/*", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    public ResponseEntity processMessageViaAjax(ModelMap model, TestLegacyJmsForm testLegacyJmsForm) {
        System.out.println(testLegacyJmsForm);
        return processMessage(model, testLegacyJmsForm);
    }

    @RequestMapping(value = "/processMessage.html", method = RequestMethod.POST)
    public ResponseEntity processMessage(ModelMap model, @ModelAttribute(TEST_LEGACY_JMS_FORM) TestLegacyJmsForm testLegacyJmsForm) {
        try {
            createCamelContextEndpointsMap();
            CamelContext springCamelContext = applicationContext.getBean(testLegacyJmsForm.getSpringContext(), SpringCamelContext.class);
            JsonNode jsonNode = isJSONValid(testLegacyJmsForm.getMessage());
            model.put("selectedDestination", testLegacyJmsForm.getDestination());
            springCamelContext.createProducerTemplate().sendBody(testLegacyJmsForm.getDestination(), createMessage(jsonNode, testLegacyJmsForm));
            testLegacyJmsForm.setMessage(null);
            model.put(RESPONSE_TEXT, SUCCESS);
            return ResponseEntity.ok(SUCCESS);
        } catch (Exception e) {
            model.put(RESPONSE_TEXT, getCause(e).toString());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(getCause(e).toString());
        } finally {
            storeJsonInModelMap(model, camelContextEndpointsMap);
            model.addAttribute(TEST_LEGACY_JMS_FORM, testLegacyJmsForm);
            model.put(SPRING_CONTEXT_LIST, camelContextList);
        }
//        return TEST_LEGACY_JMS;
    }

    public static String createMessage(JsonNode jsonNode, TestLegacyJmsForm testLegacyJmsForm) throws JsonProcessingException {
        if (jsonNode != null) {
            return jsonNode.toString();
        }
        final HashMap<String, String> sampleMessage = new HashMap<>();
        final String message = testLegacyJmsForm.getMessage() == null || testLegacyJmsForm.getMessage().trim().length() == 0
                ? new Date().toString() : testLegacyJmsForm.getMessage().trim();
        sampleMessage.put(MESSAGE, message);
        sampleMessage.put(QUEUE, testLegacyJmsForm.getDestination());
        final ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(sampleMessage);


    }

    @SuppressWarnings("squid:S1166")
    public static JsonNode isJSONValid(String jsonInString) {
        JsonNode jsonNode = null;
        try {
            final ObjectMapper mapper = new ObjectMapper();
            jsonNode = mapper.readTree(jsonInString);
        } catch (IOException e) {
            //NOSONAR
        }
        return jsonNode;
    }


    public static Throwable getCause(Throwable e) {
        Throwable cause;
        Throwable result = e;

        while (null != (cause = result.getCause()) && (result != cause)) {
            result = cause;
        }
        return result;
    }
}