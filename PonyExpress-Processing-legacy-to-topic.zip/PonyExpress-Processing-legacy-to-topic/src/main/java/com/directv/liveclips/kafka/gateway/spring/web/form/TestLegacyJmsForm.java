package com.directv.liveclips.kafka.gateway.spring.web.form;

/**
 * Created by svarkey on 22/12/16.
 */
public class TestLegacyJmsForm {
    private String springContext;
    private String destination;
    private String message;

    public TestLegacyJmsForm() {
    }

    public TestLegacyJmsForm(String springContext) {
        this.springContext = springContext;
    }

    public String getSpringContext() {
        return springContext;
    }

    public void setSpringContext(String springContext) {
        this.springContext = springContext;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "TestLegacyJmsForm{" +
                "springContext='" + springContext + '\'' +
                ", destination='" + destination + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
