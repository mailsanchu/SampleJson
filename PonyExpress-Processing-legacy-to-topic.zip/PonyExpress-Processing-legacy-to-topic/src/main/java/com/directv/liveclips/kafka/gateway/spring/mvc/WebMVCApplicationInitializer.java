package com.directv.liveclips.kafka.gateway.spring.mvc;

import org.springframework.web.WebApplicationInitializer;

import javax.servlet.ServletContext;
import java.io.InputStream;
import java.util.TreeMap;
import java.util.jar.Manifest;

public class WebMVCApplicationInitializer implements WebApplicationInitializer {
    public static final String SAMPLE_DOT_STRING = "*******************************************************************";

    public void onStartup(ServletContext servletContext) {
        try {
            InputStream inputStream = servletContext.getResourceAsStream("/META-INF/MANIFEST.MF");
            Manifest manifest = new Manifest(inputStream);
            System.out.println();
            System.out.println(SAMPLE_DOT_STRING);
            TreeMap<Object,Object> sortedMap = new TreeMap<>();
            manifest.getMainAttributes().keySet().forEach(o ->  sortedMap.put(o.toString(),manifest.getMainAttributes().get(o)));
            sortedMap.keySet().forEach(o ->  System.out.printf( "*   %-25s :::       %-25s *%n", o, sortedMap.get(o)));
            System.out.println(SAMPLE_DOT_STRING);
            System.out.println();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}