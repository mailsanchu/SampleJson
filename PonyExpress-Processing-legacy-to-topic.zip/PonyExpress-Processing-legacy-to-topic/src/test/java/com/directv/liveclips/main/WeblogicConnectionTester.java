package com.directv.liveclips.main;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.spring.SpringCamelContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;

@Component
@Configuration
public class WeblogicConnectionTester {
    public final static ObjectMapper objectMapper = new ObjectMapper();
    private final static int THREAD_WAIT_IN_MILLIS = Integer.getInteger("thread.sleep.millis", 5000);

    @Autowired
    public SpringCamelContext springCamelContext;
    @Value("${legacy.end.point.uri}")
    private String producerEndPoint;


    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.println("Usage :: Spring configuration file is required .");
            System.exit(0);
        }
        System.out.println("Time out is " + THREAD_WAIT_IN_MILLIS);
        FileSystemXmlApplicationContext applicationContext = new FileSystemXmlApplicationContext(args[0]);
        WeblogicConnectionTester weblogicConnectionTester = applicationContext.getBean(WeblogicConnectionTester.class);
        final String message = System.getProperty("test.message", new Date().toString());
        HashMap<String, String> sampleMessage = new HashMap<>();
        sampleMessage.put("message", message);
        String queueName = weblogicConnectionTester.producerEndPoint;
        sampleMessage.put("queue", queueName);
        weblogicConnectionTester.springCamelContext.
                createProducerTemplate().
                sendBody(queueName, objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(sampleMessage));
        Thread.sleep(THREAD_WAIT_IN_MILLIS);
        System.out.println("------------------------------------------------------------------------------------------");
        System.out.println("------------------------------------------------------------------------------------------");
        weblogicConnectionTester.springCamelContext.stop();
        applicationContext.close();
    }
}