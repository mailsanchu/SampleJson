package com.directv.liveclips.kafka.gateway.spring.camel.route;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class CamelRouteBuilderTest {


    @Test
    public void invalidEndPointTest() throws Exception {
        CamelRouteBuilder camelRouteBuilder = new CamelRouteBuilder();
        configureTest(camelRouteBuilder, 0);
    }

    @Test
    public void invalidLegacyEndPointTest() throws Exception {
        CamelRouteBuilder camelRouteBuilder = new CamelRouteBuilder(null, "mock:result");
        configureTest(camelRouteBuilder, 0);

    }

    @Test
    public void invalidNewEndPointTest() throws Exception {
        CamelRouteBuilder camelRouteBuilder = new CamelRouteBuilder("direct:start", null);
        configureTest(camelRouteBuilder, 0);

    }

    @Test
    public void oneEndPointConfigureTest() throws Exception {
        CamelRouteBuilder camelRouteBuilder = new CamelRouteBuilder("direct:start", "mock:result");
        configureTest(camelRouteBuilder, 1);
    }

    @Test
    public void multipleEndPointsConfigureTest() throws Exception {
        CamelRouteBuilder camelRouteBuilder = new CamelRouteBuilder("direct:start1__direct:start2", "mock:result1__mock:result2");
        configureTest(camelRouteBuilder, 2);
    }


    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void invalidConfigurationTest() throws Exception {
        CamelRouteBuilder camelRouteBuilder = new CamelRouteBuilder("direct:start1__direct:start2", "mock:result1");
        configureTest(camelRouteBuilder, 2);
    }


    private void configureTest(CamelRouteBuilder camelRouteBuilder, int expectedRoutes) throws Exception {
        camelRouteBuilder.configure();
        Assert.assertEquals(expectedRoutes, camelRouteBuilder.getRoutes().size());
        camelRouteBuilder.destroy();
    }


}
