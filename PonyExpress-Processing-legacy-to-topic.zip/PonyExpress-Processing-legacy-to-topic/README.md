# PonyExpress-Processing-legacy-to-topic
Processing service to subscribe to legacy messaging service and route to Kafka topic

# Prerequisite
#### Weblogic server up and running. Test the port 7001 is accessible
#### Kafka Server is up and running

# Install weblogic client jar on JBoss

Copy the weblogic directory from the src/resources to JBOSS_HOME/modules/system/layers/base/com folder
Add the following to JBOSS_HOME/standalone/configuration/standalone-full.xml in the global modules section 

`
<module name="com.weblogic.wlthint3client" slot="main"/>
`

Restart jboss




